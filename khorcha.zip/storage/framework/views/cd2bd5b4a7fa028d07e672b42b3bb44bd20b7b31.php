<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        

        <style media="screen">
            body{
                background: #1a2035;
            }
            .myPosition {
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                text-align: center;
                border-left: 8px solid green;
                border-right: 8px solid green;
                padding: 20px 20px;
                background: #fff;
                border-radius: 5px;
            }
            .link {
                /* margin-bottom: 50px; */
            }

            .myPosition a {
                text-decoration: none;
                font-size: 20px;
                font-weight: bold;
                display: inline-block;
                margin-bottom: 20px;
                color: darkGreen;
            }
            .myPosition a:hover {
                text-decoration: underline;
            }
        </style>

        <style>
            body {
                /* font-family: 'Nunito'; */
                font-family: "Open Sans" !important;
            }
        </style>
    </head>
    <body class="antialiased">

        <div class="myPosition">
            <?php if(Route::has('login')): ?>
                <div class="link">
                    <?php if(auth()->guard()->check()): ?>
                        <strong>You are logged In now, You can go . . .</strong>
                        <br>
                        <a href="<?php echo e(url('/home')); ?>"> Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>"> <u>Click here for Login</u> </a>
                        <p>Login Information email:<b>superadmin@dm.com</b> password:<b>123456Su</b></p>
                        
                        
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\Laravel-Project\khorcha_2\resources\views/welcome.blade.php ENDPATH**/ ?>